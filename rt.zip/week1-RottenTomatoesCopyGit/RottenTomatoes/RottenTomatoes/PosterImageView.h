//
//  PosterImageView.h
//  RottenTomatoes
//
//  Created by Anish Srivastava on 1/19/14.
//  Copyright (c) 2014 codepath. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PosterImageView : UIImageView

@end
