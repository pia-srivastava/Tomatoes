//
//  PosterImageView.m
//  RottenTomatoes
//
//  Created by Anish Srivastava on 1/19/14.
//  Copyright (c) 2014 codepath. All rights reserved.
//

#import "PosterImageView.h"

@implementation PosterImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
